<template>
  <!-- how many passes are available for this date -->
  <div>
    <v-calendar class="calendarStyle" :attributes='attributes'>
      <template #day-popover>
        <div>
         Using my own content now 
        </div>
      </template>
    </v-calendar>
  </div>
</template>

<script lang="ts">
import {defineComponent} from 'vue';
import 'v-calendar/dist/style.css'

type ticketInformation = {
  description: String,
  isAvailable: boolean,
  dates: date,
}

type date = {
  weekdays: number
}
interface Data {
  //array of custom type Array<todos>
  ticketInformation: ticketInformation[]
  
}
export default defineComponent({
  data(): Data{
    const ticketInformation = [{
      description: 'Available',
      isAvailable: false,
      dates: {weekdays: 6}
    }];

    return{
      ticketInformation,
      
    };
  },
  computed:{
    attributes(){
      return [
        ...this.ticketInformation.map(ticketInfo => ({
          dates: ticketInfo,
          dot: {
            color: ticketInfo.isAvailable? 'green' : 'red',
            class: 'opacity-75',
          },
          popover:{
            label: ticketInfo.description,
          },

        }))
      ]
    }
  }
})
</script>


<style>

</style>
