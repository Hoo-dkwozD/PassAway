import { createRouter, createWebHistory } from 'vue-router'
import MainView from '../views/MainView.vue'
import SampleView from '../views/SampleView.vue'
import Booking from '../views/BookingView.vue'
import BookingConfirmation from '../views/BookingConfirmation.vue';
import ProfileView from '../views/ProfileView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'booking',
      component: Booking
    },
    {
      path: '/profile',
      name: 'profile',
      component: ProfileView
    },
    {
    path:'/bookingconfirmation',
    name: 'bookingconfirmation',
    component: BookingConfirmation
    }

  ]
});

export default router
