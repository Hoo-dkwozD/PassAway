<template>
  <div class="app">
    <nav>
    <RouterLink to="/sample">
      Sample
    </RouterLink>
    |
    <RouterLink to="/home">
      HomeView
    </RouterLink>

  </nav>
  <router-view/>
  </div>

</template>


<script lang="ts">
import { defineComponent } from 'vue'


export default defineComponent({
  name: 'App',

  data () {
    return {
      //
    }
  },
})
</script>


<style scoped>
*{
  padding: 0;
  margin: 0;
}
.app{
  text-align: center;
}
</style>